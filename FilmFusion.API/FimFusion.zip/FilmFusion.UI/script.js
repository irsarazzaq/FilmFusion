// @ts-nocheck
const API_URL = 'https://localhost:7249/api';

// ========== INDEX PAGE AUTH FUNCTIONS ==========
window.selectedRole = null;

window.selectRole = function (role) {
    window.selectedRole = role;
    const adminBtn = document.getElementById('adminRoleBtn');
    const userBtn = document.getElementById('userRoleBtn');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const loginTitle = document.getElementById('loginTitle');

    if (adminBtn) adminBtn.classList.toggle('active', role === 'admin');
    if (userBtn) userBtn.classList.toggle('active', role === 'user');
    if (loginForm) loginForm.style.display = 'block';
    if (signupForm) signupForm.style.display = role === 'user' ? 'block' : 'none';
    if (loginTitle) loginTitle.innerText = role === 'admin' ? 'Admin Login' : 'User Login';
};

window.handleLogin = async function () {
    const email = document.getElementById('loginEmail')?.value;
    const password = document.getElementById('loginPassword')?.value;

    if (window.selectedRole === 'admin') {
        if (email === 'admin@filmfusion.com' && password === 'admin123') {
            localStorage.setItem('userId', '1');
            localStorage.setItem('userName', 'Admin');
            localStorage.setItem('userRole', 'Admin');
            window.location.href = 'admin-dashboard.html';
        } else {
            alert('Invalid admin credentials! Use: admin@filmfusion.com / admin123');
        }
    } else {
        try {
            const res = await fetch(`${API_URL}/Auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            if (res.ok) {
                localStorage.setItem('userId', data.userId);
                localStorage.setItem('userName', data.username);
                localStorage.setItem('userRole', 'User');
                window.location.href = 'user-dashboard.html';
            } else {
                alert(data.message || 'Login failed');
            }
        } catch (err) {
            alert('Error: ' + err.message);
        }
    }
};

window.handleSignup = async function () {
    const username = document.getElementById('signupUsername')?.value;
    const email = document.getElementById('signupEmail')?.value;
    const password = document.getElementById('signupPassword')?.value;

    try {
        const res = await fetch(`${API_URL}/Auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        if (res.ok) {
            alert('Signup successful! Please login.');
            document.getElementById('signupForm').style.display = 'none';
        } else {
            alert('Signup failed');
        }
    } catch (err) {
        alert('Error: ' + err.message);
    }
};

// ========== COMMON FUNCTIONS ==========
window.logout = function () {
    localStorage.clear();
    window.location.href = 'index.html';
};

async function loadMovies() {
    try {
        const res = await fetch(`${API_URL}/Movies`);
        const movies = await res.json();
        displayMovies(movies);
    } catch (e) { console.error(e); }
}

function displayMovies(movies) {
    const grid = document.getElementById('moviesGrid');
    if (!grid) return;
    if (!movies?.length) { grid.innerHTML = '<p>No movies found.</p>'; return; }

    const isAdmin = localStorage.getItem('userRole') === 'Admin';
    grid.innerHTML = movies.map(m => `
        <div class="movie-card" onclick="viewMovie(${m.id})" style="cursor:pointer;">
            ${m.posterPath ? `<img src="https://image.tmdb.org/t/p/w200${m.posterPath}" style="width:100%; border-radius:12px;">` : ''}
            <div class="movie-title">${m.title}</div>
            <div class="movie-year">${m.year} • ${m.genre}</div>
            <div class="movie-rating">⭐ ${m.rating}/10</div>
            <p style="font-size:0.9rem; color:#666;">${(m.overview || 'No description.').substring(0, 100)}...</p>
            ${isAdmin ? `<button class="btn btn-danger" onclick="event.stopPropagation(); deleteMovie(${m.id})">Delete</button>` : ''}
        </div>
    `).join('');
}

window.viewMovie = function (id) {
    if (id) window.location.href = `watch-movie.html?id=${id}`;
};

window.searchMovies = async function () {
    const q = document.getElementById('searchInput')?.value.trim();
    if (!q) { loadMovies(); return; }
    const res = await fetch(`${API_URL}/Movies/search?query=${encodeURIComponent(q)}`);
    displayMovies(await res.json());
};

window.filterByGenre = async function () {
    const g = document.getElementById('genreFilter')?.value;
    if (!g) { loadMovies(); return; }
    const res = await fetch(`${API_URL}/Movies/genre/${g}`);
    displayMovies(await res.json());
};

async function addMovie() {
    const movie = {
        title: document.getElementById('movieTitle')?.value,
        genre: document.getElementById('movieGenre')?.value,
        year: parseInt(document.getElementById('movieYear')?.value),
        rating: parseFloat(document.getElementById('movieRating')?.value),
        description: document.getElementById('movieDescription')?.value,
        tags: document.getElementById('movieTags')?.value
    };
    const res = await fetch(`${API_URL}/Movies`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(movie) });
    if (res.ok) { alert('Movie added!'); closeModals(); loadMovies(); }
    else alert('Failed');
}

async function deleteMovie(id) {
    if (!confirm('Delete this movie?')) return;
    const res = await fetch(`${API_URL}/Movies/${id}`, { method: 'DELETE' });
    if (res.ok) { alert('Deleted!'); loadMovies(); }
    else alert('Failed');
}

function closeModals() {
    ['loginModal', 'signupModal', 'addMovieModal', 'importModal'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
}

window.showAddMovieModal = function () {
    const modal = document.getElementById('addMovieModal');
    if (modal) modal.style.display = 'flex';
};

// ========== WATCH MOVIE PAGE FUNCTIONS ==========
let currentMovieId = null;

async function loadMovieForWatch() {
    const urlParams = new URLSearchParams(window.location.search);
    currentMovieId = urlParams.get('id');
    if (!currentMovieId) return;

    const res = await fetch(`${API_URL}/Movies/${currentMovieId}`);
    const movie = await res.json();

    const titleEl = document.getElementById('movieTitle');
    const overviewEl = document.getElementById('movieOverview');
    const ratingEl = document.getElementById('movieRating');
    const genreEl = document.getElementById('movieGenre');
    const directorEl = document.getElementById('movieDirector');
    const castEl = document.getElementById('movieCast');
    const playerEl = document.getElementById('moviePlayer');

    if (titleEl) titleEl.innerText = movie.title;
    if (overviewEl) overviewEl.innerText = movie.overview || 'No description.';
    if (ratingEl) ratingEl.innerText = movie.rating;
    if (genreEl) genreEl.innerText = movie.genre;
    if (directorEl) directorEl.innerText = movie.director || 'N/A';
    if (castEl) castEl.innerText = movie.cast || 'N/A';

    if (playerEl) {
        if (movie.trailerUrl) {
            const videoId = movie.trailerUrl.split('v=')[1];
            playerEl.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
        } else {
            const searchQuery = encodeURIComponent(movie.title + ' full movie');
            playerEl.src = `https://www.youtube.com/embed?listType=search&q=${searchQuery}&autoplay=1`;
        }
    }
    loadCommentsForWatch();
}

async function loadCommentsForWatch() {
    if (!currentMovieId) return;
    const res = await fetch(`${API_URL}/Movies/${currentMovieId}/comments`);
    const comments = await res.json();
    const container = document.getElementById('commentsList');
    if (!container) return;
    if (!comments?.length) { container.innerHTML = '<p>No comments yet.</p>'; return; }
    container.innerHTML = comments.map(c => `
        <div style="padding:0.8rem; border-bottom:1px solid #ddd;">
            <strong>${c.username || 'User'}</strong>
            <div style="margin-top:0.3rem;">${c.comment}</div>
            <div style="font-size:0.8rem; color:#888;">${new Date(c.commentDate).toLocaleString()}</div>
        </div>
    `).join('');
}

window.addCommentForWatch = async function () {
    const input = document.getElementById('commentInput');
    const comment = input?.value.trim();
    if (!comment) return;
    const userId = localStorage.getItem('userId');
    if (!userId) return;
    await fetch(`${API_URL}/Movies/comment`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: parseInt(userId), movieId: parseInt(currentMovieId), comment })
    });
    if (input) input.value = '';
    loadCommentsForWatch();
    alert('Comment added!');
};

window.likeMovie = function () { alert('Thanks for liking!'); };
window.dislikeMovie = function () { alert('Sorry you disliked!'); };

window.toggleFavorite = async function () {
    const userId = localStorage.getItem('userId');
    if (!userId || !currentMovieId) return;
    await fetch(`${API_URL}/Movies/favorite`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: parseInt(userId), movieId: parseInt(currentMovieId) })
    });
    alert('Added to favorites!');
};

window.toggleWatchlist = async function () {
    const userId = localStorage.getItem('userId');
    if (!userId || !currentMovieId) return;
    await fetch(`${API_URL}/Movies/watchlist`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: parseInt(userId), movieId: parseInt(currentMovieId) })
    });
    alert('Added to watchlist!');
};

// ========== FAVORITES PAGE ==========
async function loadFavorites() {
    const userId = localStorage.getItem('userId');
    const res = await fetch(`${API_URL}/Movies/favorites/${userId}`);
    const movies = await res.json();
    const grid = document.getElementById('favoritesGrid');
    if (!grid) return;
    if (!movies?.length) { grid.innerHTML = '<p>No favorites yet.</p>'; return; }
    grid.innerHTML = movies.map(m => `
        <div class="movie-card" onclick="viewMovie(${m.id})" style="cursor:pointer;">
            ${m.posterPath ? `<img src="https://image.tmdb.org/t/p/w200${m.posterPath}" style="width:100%; border-radius:12px;">` : ''}
            <div class="movie-title">${m.title}</div>
            <div class="movie-year">${m.year} • ${m.genre}</div>
            <div class="movie-rating">⭐ ${m.rating}/10</div>
            <button class="btn btn-danger" onclick="event.stopPropagation(); removeFromFavorites(${m.id})">Remove</button>
        </div>
    `).join('');
}

async function removeFromFavorites(movieId) {
    const userId = localStorage.getItem('userId');
    await fetch(`${API_URL}/Movies/favorite?userId=${userId}&movieId=${movieId}`, { method: 'DELETE' });
    loadFavorites();
    alert('Removed from favorites');
}

// ========== WATCHLIST PAGE ==========
async function loadWatchlist() {
    const userId = localStorage.getItem('userId');
    const res = await fetch(`${API_URL}/Movies/watchlist/${userId}`);
    const movies = await res.json();
    const grid = document.getElementById('watchlistGrid');
    if (!grid) return;
    if (!movies?.length) { grid.innerHTML = '<p>Watchlist empty.</p>'; return; }
    grid.innerHTML = movies.map(m => `
        <div class="movie-card" onclick="viewMovie(${m.id})" style="cursor:pointer;">
            ${m.posterPath ? `<img src="https://image.tmdb.org/t/p/w200${m.posterPath}" style="width:100%; border-radius:12px;">` : ''}
            <div class="movie-title">${m.title}</div>
            <div class="movie-year">${m.year} • ${m.genre}</div>
            <div class="movie-rating">⭐ ${m.rating}/10</div>
            <button class="btn btn-danger" onclick="event.stopPropagation(); removeFromWatchlist(${m.id})">Remove</button>
        </div>
    `).join('');
}

async function removeFromWatchlist(movieId) {
    const userId = localStorage.getItem('userId');
    await fetch(`${API_URL}/Movies/watchlist?userId=${userId}&movieId=${movieId}`, { method: 'DELETE' });
    loadWatchlist();
    alert('Removed from watchlist');
}

// ========== ADMIN FUNCTIONS ==========
async function loadDashboardStats() {
    const res = await fetch(`${API_URL}/Admin/dashboard`);
    const stats = await res.json();
    const grid = document.getElementById('statsGrid');
    if (grid) grid.innerHTML = `
        <div class="stat-card"><div class="stat-number">${stats.totalUsers}</div><div>Total Users</div></div>
        <div class="stat-card"><div class="stat-number">${stats.totalMovies}</div><div>Total Movies</div></div>
    `;
}

async function loadAllUsers() {
    const res = await fetch(`${API_URL}/Admin/users`);
    const users = await res.json();
    const container = document.getElementById('usersList');
    if (!container) return;
    if (!users?.length) { container.innerHTML = '<p>No users.</p>'; return; }
    let html = '<table style="width:100%; border-collapse:collapse;"><tr style="background:#f0f0f0;"><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Action</th></tr>';
    for (let u of users) {
        html += `<tr><td>${u.id}</td><td>${u.username}</td><td>${u.email}</td><td>${u.role}</td><td><button class="btn btn-danger" onclick="deleteUser(${u.id})">Delete</button></td></tr>`;
    }
    html += '</table>';
    container.innerHTML = html;
}

async function deleteUser(id) {
    if (!confirm('Delete user?')) return;
    const res = await fetch(`${API_URL}/Admin/user/${id}`, { method: 'DELETE' });
    if (res.ok) { loadAllUsers(); loadDashboardStats(); alert('User deleted'); }
}

// ========== TMDB IMPORT ==========
window.searchTMDB = async function () {
    const q = document.getElementById('tmdbSearchQuery')?.value;
    if (!q) return;
    const res = await fetch(`${API_URL}/Movies/search-tmdb?query=${encodeURIComponent(q)}`);
    const results = await res.json();
    const container = document.getElementById('tmdbResults');
    if (container) {
        let html = '';
        for (let m of results) {
            html += `<div style="display:flex; justify-content:space-between; padding:5px; border-bottom:1px solid #ddd;">
                <span>${m.title} (${m.release_date?.split('-')[0] || 'N/A'})</span>
                <button onclick="importMovie(${m.id})">Import</button>
            </div>`;
        }
        container.innerHTML = html;
    }
};

window.importMovie = async function (tmdbId) {
    const res = await fetch(`${API_URL}/Movies/import/${tmdbId}`, { method: 'POST' });
    if (res.ok) { alert('Movie imported!'); closeModals(); loadMovies(); }
    else alert('Import failed');
};

window.showImportModal = function () {
    const m = document.getElementById('importModal');
    if (m) m.style.display = 'flex';
};

// ========== CHATBOT FUNCTIONS ==========
window.sendMessage = async function () {
    const input = document.getElementById('chatInput');
    const msg = input?.value.trim();
    if (!msg) return;
    addMessage(msg, 'user');
    if (input) input.value = '';
    addTypingIndicator();
    setTimeout(async () => {
        removeTypingIndicator();
        const recommendations = await getMovieRecommendations(msg);
        addMessage(generateBotResponse(msg, recommendations), 'bot');
        if (recommendations?.length) showRecommendations(recommendations);
    }, 1000);
};

function addMessage(text, sender) {
    const chat = document.getElementById('chatMessages');
    if (!chat) return;
    const div = document.createElement('div');
    div.className = `message ${sender}-message`;
    div.innerHTML = `<div class="message-content">${text}</div>`;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function addTypingIndicator() {
    const chat = document.getElementById('chatMessages');
    if (!chat) return;
    const div = document.createElement('div');
    div.className = 'message bot-message';
    div.id = 'typingIndicator';
    div.innerHTML = '<div class="message-content">🤔 Thinking...</div>';
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function removeTypingIndicator() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
}

async function getMovieRecommendations(query) {
    const q = query.toLowerCase();
    let genre = '';
    if (q.includes('horror')) genre = 'horror';
    else if (q.includes('comedy')) genre = 'comedy';
    else if (q.includes('action')) genre = 'action';
    else if (q.includes('romance')) genre = 'romance';
    else if (q.includes('sci-fi')) genre = 'sci-fi';
    else if (q.includes('drama')) genre = 'drama';
    else if (q.includes('thriller')) genre = 'thriller';
    try {
        if (genre) {
            const res = await fetch(`${API_URL}/Movies/genre/${genre}`);
            return await res.json();
        } else {
            const res = await fetch(`${API_URL}/Movies`);
            const movies = await res.json();
            movies.sort((a, b) => b.rating - a.rating);
            return movies.slice(0, 5);
        }
    } catch (e) { return []; }
}

function generateBotResponse(query, recs) {
    const q = query.toLowerCase();
    if (q.includes('sad')) return '😊 Feeling sad? Here are some comedies to cheer you up:';
    if (q.includes('happy')) return '🎉 Great mood! Check out these action movies:';
    if (q.includes('horror') || q.includes('scared')) return '👻 Feeling brave? Here are some horror movies:';
    if (recs?.length) return '🎬 Based on your request, here are some recommendations:';
    return '🎬 Here are some popular movies you might enjoy:';
}

function showRecommendations(movies) {
    const section = document.getElementById('recommendationsSection');
    const grid = document.getElementById('recommendationsGrid');
    if (!section || !grid) return;
    if (movies?.length) {
        section.style.display = 'block';
        let html = '';
        for (let m of movies) {
            html += `<div class="movie-card" onclick="viewMovie(${m.id})" style="cursor:pointer;">
                <div class="movie-title">${m.title}</div>
                <div class="movie-year">${m.year} • ${m.genre}</div>
                <div class="movie-rating">⭐ ${m.rating}/10</div>
            </div>`;
        }
        grid.innerHTML = html;
    } else {
        section.style.display = 'none';
    }
}

// ========== PAGE INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
    // User Dashboard
    if (document.getElementById('moviesGrid') && !document.getElementById('statsGrid')) {
        const userId = localStorage.getItem('userId');
        if (!userId) window.location.href = 'index.html';
        loadMovies();
    }
    // Admin Dashboard
    if (document.getElementById('statsGrid')) {
        const userId = localStorage.getItem('userId');
        const userRole = localStorage.getItem('userRole');
        if (!userId || userRole !== 'Admin') window.location.href = 'index.html';
        loadDashboardStats();
        loadAllUsers();
        loadMovies();
    }
    // Favorites Page
    if (document.getElementById('favoritesGrid')) {
        const userId = localStorage.getItem('userId');
        if (!userId) window.location.href = 'index.html';
        loadFavorites();
    }
    // Watchlist Page
    if (document.getElementById('watchlistGrid')) {
        const userId = localStorage.getItem('userId');
        if (!userId) window.location.href = 'index.html';
        loadWatchlist();
    }
    // Watch Movie Page
    if (document.getElementById('moviePlayer')) {
        const userId = localStorage.getItem('userId');
        if (!userId) window.location.href = 'index.html';
        loadMovieForWatch();
    }
    // Close modals when clicking outside
    window.onclick = (e) => {
        if (e.target?.classList?.contains('modal')) {
            e.target.style.display = 'none';
        }
    };
});